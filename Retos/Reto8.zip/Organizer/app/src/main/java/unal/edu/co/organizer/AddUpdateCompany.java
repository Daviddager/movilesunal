package unal.edu.co.organizer;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import unal.edu.co.organizer.DB.CompanyOperations;

/**
 * Created by drdagermo on 15/11/2017.
 */

public class AddUpdateCompany extends AppCompatActivity {

    private Button addUpdateButton;
    private Company oldCompany, newCompany;
    private CompanyOperations companyData;
    private EditText mCompanyName;
    private EditText mCompanyURL;
    private EditText mContactEmail;
    private EditText mContactNumber;
    private EditText mProduct;
    private EditText mService;
    private long compId;
    private RadioGroup mRadioGroup;
    private RadioButton mConsultancy;
    private RadioButton mDevelopment;
    private RadioButton mFactory;
    private String mode;
    private static final String EXTRA_COMP_ID = "unal.edu.co.compId";
    private static final String EXTRA_ADD_UPDATE = "unal.edu.co.add_update";

    @Override
    protected void onCreate( Bundle savedInstanceState ){
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_add_update_company );
        newCompany = new Company();
        oldCompany = new Company();
        mCompanyName = ( EditText ) findViewById( R.id.edit_text_company_name );
        mCompanyURL = ( EditText ) findViewById( R.id.edit_text_url );
        mContactEmail = ( EditText ) findViewById( R.id.edit_text_email );
        mContactNumber = ( EditText ) findViewById( R.id.edit_text_number );
        mRadioGroup = ( RadioGroup ) findViewById( R.id.radio_type );
        mConsultancy = ( RadioButton ) findViewById( R.id.radio_consultancy );
        mDevelopment = ( RadioButton ) findViewById( R.id.radio_development );
        mFactory = ( RadioButton ) findViewById( R.id.radio_factory );
        mProduct = ( EditText ) findViewById( R.id.edit_text_products );
        mService = ( EditText ) findViewById( R.id.edit_text_services );
        addUpdateButton = ( Button ) findViewById( R.id.button_add_update_company );
        companyData = new CompanyOperations( this );
        companyData.open();

        mode = getIntent().getStringExtra( EXTRA_ADD_UPDATE );
        if( mode.equals( "Update" ) ){
            addUpdateButton.setText( "Update Company" );
            compId = getIntent().getLongExtra( EXTRA_COMP_ID, 0 );
            initializeCompany( compId );
        }

        mRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {
                // find which radio button is selected
                if( checkedId == R.id.radio_consultancy ){
                    newCompany.setCompanyType( "Consultancy" );
                    if( mode.equals( "Update" ) ){
                        oldCompany.setCompanyType( "Consultancy" );
                    }
                }else if( checkedId == R.id.radio_development ){
                    newCompany.setCompanyType( "Development" );
                    if( mode.equals( "Update" ) ){
                        oldCompany.setCompanyType( "Development" );
                    }
                }else{
                    newCompany.setCompanyType( "Factory" );
                    if( mode.equals( "Update" ) ){
                        oldCompany.setCompanyType( "Factory" );
                    }
                }
            }
        });

        addUpdateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if( mode.equals( "Add" ) ){
                    newCompany.setCompanyName( mCompanyName.getText().toString() );
                    newCompany.setCompanyUrl( mCompanyURL.getText().toString() );
                    newCompany.setContactEmail( mContactEmail.getText().toString() );
                    newCompany.setContactNumber( Integer.valueOf( mContactNumber.getText( ).toString() ) );
                    newCompany.setProducts( mProduct.getText().toString() );
                    newCompany.setServices( mService.getText().toString() );
                    if( mRadioGroup.getCheckedRadioButtonId( ) == R.id.radio_consultancy ) {
                        newCompany.setCompanyType("Consultancy");
                    }else if( mRadioGroup.getCheckedRadioButtonId( ) == R.id.radio_consultancy ) {
                        newCompany.setCompanyType( "Development" );
                    }else{
                        newCompany.setCompanyType( "Factory" );
                    }
                    companyData.addCompany( newCompany );
                    Toast.makeText( AddUpdateCompany.this, "Company " + newCompany.getCompanyName() + " has been added successfully", Toast.LENGTH_SHORT ).show();
                    Intent intent = new Intent( AddUpdateCompany.this, MainActivity.class );
                    startActivity( intent );
                }
                else{
                    oldCompany.setCompanyName( mCompanyName.getText().toString() );
                    oldCompany.setCompanyUrl( mCompanyURL.getText().toString() );
                    oldCompany.setContactEmail( mContactEmail.getText().toString() );
                    oldCompany.setContactNumber( Integer.valueOf( mContactNumber.getText( ).toString() ) );
                    oldCompany.setProducts( mProduct.getText().toString() );
                    oldCompany.setServices( mService.getText().toString() );
                    companyData.updateCompany( oldCompany );
                    Toast.makeText( AddUpdateCompany.this, "Company " + oldCompany.getCompanyName() + " has been added successfully", Toast.LENGTH_SHORT ).show();
                    Intent intent = new Intent( AddUpdateCompany.this, MainActivity.class );
                    startActivity( intent );
                }
            }
        });
    }

    private void initializeCompany( long compId ){
        oldCompany = companyData.getCompany( compId );
        mCompanyName.setText( oldCompany.getCompanyName() );
        mCompanyURL.setText( oldCompany.getCompanyUrl() );
        mContactEmail.setText( oldCompany.getContactEmail() );
        mContactNumber.setText( String.valueOf( oldCompany.getContactNumber() ) );
        mProduct.setText( oldCompany.getProducts() );
        mService.setText( oldCompany.getServices() );
        if( oldCompany.getCompanyType().equals( "Consultancy" ) ){
            mRadioGroup.check( R.id.radio_consultancy );
        }else if( oldCompany.getCompanyType().equals( "Development" )  ){
            mRadioGroup.check( R.id.radio_development );
        }else{
            mRadioGroup.check( R.id.radio_factory );
        }
    }

}
