package unal.edu.co.organizer.DB;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by drdagerm on 11/13/17.
 */

public class CompanyHandler extends SQLiteOpenHelper{


    private static final String DATABASE_NAME = "companies.db";
    private static final int DATABASE_VERSION = 1;

    public static String TABLE_COMPANIES = "companies";
    public static String COLUMN_ID = "companyId";
    public static String COLUMN_NAME = "companyName";
    public static String COLUMN_URL = "companuURL";
    public static String COLUMN_CONTACT_EMAIL = "contactEmail";
    public static String COLUMN_CONTACT_NUMBER = "contactNumber";
    public static String COLUMN_PRODUCTS = "products";
    public static String COLUMN_SERVICES = "services";
    public static String COLUMN_COMPANY_TYPE = "companyType";

    private static final String TABLE_CREATE = "CREATE TABLE " + TABLE_COMPANIES +
            " (" +
            COLUMN_ID + "INTEGER PRIMARY KEY AUTOINCREMT, " +
            COLUMN_NAME + " TEXT, " +
            COLUMN_URL + " TEXT, " +
            COLUMN_CONTACT_EMAIL + " TEXT, " +
            COLUMN_CONTACT_NUMBER + " TEXT, " +
            COLUMN_PRODUCTS + " TEXT, " +
            COLUMN_SERVICES + " TEXT, " +
            COLUMN_COMPANY_TYPE  + " TEXT " +
            ")";

    public CompanyHandler( Context context ){
        super( context, DATABASE_NAME, null, DATABASE_VERSION );
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL( TABLE_CREATE );
    }

    @Override
    public void onUpgrade( SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion ) {
        sqLiteDatabase.execSQL( "DROP TABLE IF EXISTS " + TABLE_COMPANIES );
        sqLiteDatabase.execSQL( TABLE_CREATE );
    }
}
