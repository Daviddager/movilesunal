package unal.edu.co.organizer;

/**
 * Created by drdagerm on 11/13/17.
 */

public class Company {

    private long companyId;
    private String companyName;
    private String companyUrl;
    private String contactEmail;
    private Integer contactNumber;
    private String products;
    private String services;
    private String companyType;

    public Company( long companyId, String companyName, String companyUrl, String contactEmail, Integer contactNumber, String products, String services, String companyType ){
        this.companyId = companyId;
        this.companyName = companyName;
        this.companyUrl = companyUrl;
        this.contactEmail = contactEmail;
        this.contactNumber = contactNumber;
        this.products = products;
        this.services = services;
        this.companyType = companyType;
    }

    public Company(){

    }


    public void setCompanyId(long companyId) {
        this.companyId = companyId;
    }

    public long getCompanyId() {
        return companyId;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyUrl(String companyUrl) {
        this.companyUrl = companyUrl;
    }

    public String getCompanyUrl() {
        return companyUrl;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public int getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(int contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getProducts() {
        return products;
    }

    public void setProducts(String products) {
        this.products = products;
    }

    public String getServices() {
        return services;
    }

    public void setServices(String services) {
        this.services = services;
    }

    public String getCompanyType() {
        return companyType;
    }

    public void setCompanyType(String companyType) {
        this.companyType = companyType;
    }

    public String toString(){
        return "Comp id: " + getCompanyId() + "\n" +
                "Name: " + getCompanyName() + "\n" +
                "URL: " + getCompanyUrl() + "\n" +
                "Contact Email: " + getContactEmail();
    }
}
