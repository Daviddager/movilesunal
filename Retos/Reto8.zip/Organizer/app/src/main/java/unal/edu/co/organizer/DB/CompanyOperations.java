package unal.edu.co.organizer.DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.nio.charset.CoderMalfunctionError;
import java.util.ArrayList;
import java.util.List;

import unal.edu.co.organizer.Company;

/**
 * Created by drdagerm on 11/13/17.
 */

public class CompanyOperations {
    public static final String LOGTAG = "COMP_MNGMNT_SYS";

    SQLiteOpenHelper dbHandler;
    SQLiteDatabase database;

    private static final String[] allColumns = {
            CompanyHandler.COLUMN_ID,
            CompanyHandler.COLUMN_NAME,
            CompanyHandler.COLUMN_URL,
            CompanyHandler.COLUMN_CONTACT_EMAIL,
            CompanyHandler.COLUMN_CONTACT_NUMBER,
            CompanyHandler.COLUMN_PRODUCTS,
            CompanyHandler.COLUMN_SERVICES,
            CompanyHandler.COLUMN_COMPANY_TYPE
    };

    public CompanyOperations( Context context ){
        dbHandler = new CompanyHandler( context );
    }

    public void open(){
        Log.i( LOGTAG, "Database Opened" );
        database = dbHandler.getWritableDatabase();
    }

    public void close(){
        Log.i( LOGTAG, "Database Closed" );
        dbHandler.close();
    }

    public Company addCompany( Company company ){
        ContentValues values = new ContentValues();
        values.put( CompanyHandler.COLUMN_NAME, company.getCompanyName() );
        values.put( CompanyHandler.COLUMN_URL, company.getCompanyUrl() );
        values.put( CompanyHandler.COLUMN_CONTACT_EMAIL, company.getContactEmail() );
        values.put( CompanyHandler.COLUMN_CONTACT_NUMBER, company.getContactNumber() );
        values.put( CompanyHandler.COLUMN_PRODUCTS, company.getProducts() );
        values.put( CompanyHandler.COLUMN_SERVICES, company.getServices() );
        values.put( CompanyHandler.COLUMN_COMPANY_TYPE, company.getCompanyType() );
        long insertId = database.insert( CompanyHandler.TABLE_COMPANIES, null, values );
        company.setCompanyId( insertId );
        return company;
    }

    // Getting single company
    public Company getCompany( long id ){
        Cursor cursor = database.query( CompanyHandler.TABLE_COMPANIES, allColumns, CompanyHandler.COLUMN_ID + "=?", new String[]{ String.valueOf( id ) }, null, null, null, null );
        if( cursor != null )
            cursor.moveToFirst();
        Company c = new Company( Long.parseLong( cursor.getString( 0 ) ), cursor.getString( 1 ), cursor.getString( 2 ), cursor.getString( 3 ) , Integer.getInteger( cursor.getString( 4 ) ), cursor.getString( 5 ), cursor.getString( 6 ), cursor.getString( 7 ) );
        return c;
    }

    public List<Company> getAllCompanies(){
        Cursor cursor = database.query( CompanyHandler.TABLE_COMPANIES, allColumns, null, null, null, null, null );
        List<Company> companies = new ArrayList<>();
        if( cursor.getCount() > 0 ){
            while( cursor.moveToNext() ){
                Company company = new Company();
                company.setCompanyId( cursor.getLong( cursor.getColumnIndex( CompanyHandler.COLUMN_ID ) ) );
                company.setCompanyName( cursor.getString( cursor.getColumnIndex( CompanyHandler.COLUMN_NAME ) ) );
                company.setCompanyUrl( cursor.getString( cursor.getColumnIndex( CompanyHandler.COLUMN_URL ) ) );
                company.setContactEmail( cursor.getString( cursor.getColumnIndex( CompanyHandler.COLUMN_CONTACT_EMAIL ) ) );
                company.setContactNumber( cursor.getInt( cursor.getColumnIndex( CompanyHandler.COLUMN_CONTACT_NUMBER ) ) );
                company.setProducts( cursor.getString( cursor.getColumnIndex( CompanyHandler.COLUMN_PRODUCTS ) ) );
                company.setServices( cursor.getString( cursor.getColumnIndex( CompanyHandler.COLUMN_SERVICES ) ) );
                company.setCompanyType( cursor.getString( cursor.getColumnIndex( CompanyHandler.COLUMN_COMPANY_TYPE ) ) );
                companies.add( company );
            }
        }
        // Return Companies
        return companies;
    }

    public int updateCompany( Company company ){
        
    }
}