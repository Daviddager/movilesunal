package unal.edu.co.organizer;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import unal.edu.co.organizer.DB.CompanyOperations;

public class MainActivity extends AppCompatActivity {

    private Button addCompanyButton;
    private Button editCompanyButton;
    private Button deleteCompanyButton;
    private Button viewAllCompaniesButton;
    private CompanyOperations companiesOps;

    private static final String EXTRA_COMP_ID = "unal.edu.co.compId";
    private static final String EXTRA_ADD_UPDATE = "unal.edu.co.add_update";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        addCompanyButton = (Button) findViewById(R.id.button_add_company);
        editCompanyButton = (Button) findViewById(R.id.button_edit_company);
        deleteCompanyButton = (Button) findViewById(R.id.button_delete_company);
        viewAllCompaniesButton = (Button) findViewById(R.id.button_view_companies);

        companiesOps = new CompanyOperations( this );

        addCompanyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddUpdateCompany.class);
                intent.putExtra(EXTRA_ADD_UPDATE, "Add");
                startActivity(intent);
            }
        });

        editCompanyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getCompIdAndUpdateComp();
            }
        });

        deleteCompanyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getCompIdAndRemoveComp();
            }
        });

        viewAllCompaniesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ViewAllCompanies.class);
                startActivity(intent);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.company_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.menu_item_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void getCompIdAndUpdateComp() {
        LayoutInflater inflater = LayoutInflater.from( this );
        View getCompIdView = inflater.inflate( R.layout.dialog_get_comp_id, null );

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder( this );
        // set dialog_get_comp_id.xml to alertdialog builder
        alertDialogBuilder.setView( getCompIdView );

        final EditText userInput = ( EditText ) getCompIdView.findViewById( R.id.editTextDialogUserInput );

        // set dialog message
        alertDialogBuilder
                .setCancelable( false )
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int id) {
                        // get user input and set it to result
                        // edit text
                        Intent intent = new Intent( MainActivity.this, AddUpdateCompany.class );
                        intent.putExtra( EXTRA_ADD_UPDATE, "Update" );
                        intent.putExtra( EXTRA_COMP_ID, Long.parseLong( userInput.getText().toString() ) );
                        startActivity( intent );
                    }
                }).create()
                .show();
    }

    public void getCompIdAndRemoveComp(){
        LayoutInflater inflater = LayoutInflater.from( this );
        View getCompIdView = inflater.inflate( R.layout.dialog_get_comp_id, null );

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder( this );
        // set dialog_get_comp_id.xml to alertdialog builder
        alertDialogBuilder.setView( getCompIdView );

        final EditText userInput = ( EditText ) getCompIdView.findViewById( R.id.editTextDialogUserInput );

        // set dialog message
        alertDialogBuilder
                .setCancelable( false )
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int id) {
                        // get user input and set it to result
                        // edit text
                        companiesOps = new CompanyOperations( MainActivity.this );
                        companiesOps.removeCompany( companiesOps.getCompany( Long.parseLong( userInput.getText().toString() ) ) );
                        Toast toast = Toast.makeText( MainActivity.this, "Company removed successfully!", Toast.LENGTH_SHORT );
                        toast.show();
                    }
                }).create()
                .show();
    }

    @Override
    protected void onResume(){
        super.onResume();
        companiesOps.open();
    }

    @Override
    protected  void onPause(){
        super.onPause();
        companiesOps.close();
    }
}
