package unal.edu.co.organizer;

import android.app.ListActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;

import java.util.List;

import unal.edu.co.organizer.DB.CompanyOperations;

/**
 * Created by drdagermo on 15/11/2017.
 */

class ViewAllCompanies extends ListActivity {

    private CompanyOperations companyOperations;
    List<Company> companies;

    @Override
    protected void onCreate( Bundle savedInstaceState ){
        super.onCreate( savedInstaceState );
        setContentView( R.layout.activity_view_all_companies );
        companyOperations = new CompanyOperations( this );
        companyOperations.open();
        companies = companyOperations.getAllCompanies();
        companyOperations.close();
        ArrayAdapter<Company> adapter = new ArrayAdapter<>( this, android.R.layout.simple_list_item_1, companies );
        setListAdapter( adapter );
    }
}
