package unal.edu.co.tictactoe;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private static int DELAY = 900;

    private TicTacToeGame mGame;
    private BoardView mBoardView;

    private SharedPreferences mPrefs;

    private TextView mInfoTextView;
    private TextView mAndroidScoreTextView;
    private TextView mHumanScoreTextView;
    private TextView mTieScoreTextView;

    private MediaPlayer mHumanMediaPlayer;
    private MediaPlayer mComputerMediaPlayer;

    private Random mRand;

    private int mAndroidScore = 0;
    private int mHumanScore = 0;
    private int mTieScore = 0;
    private int mHumanTurn;
    private boolean mGameOver;
    private boolean mSoundOn;

    static final int DIALOG_QUIT_ID = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mRand = new Random();

        mInfoTextView = ( TextView ) findViewById( R.id.information );
        mAndroidScoreTextView = ( TextView ) findViewById( R.id.android_score );
        mHumanScoreTextView = ( TextView ) findViewById( R.id.human_score );
        mTieScoreTextView = ( TextView ) findViewById( R.id.tie_score );

        mGame = new TicTacToeGame();
        mBoardView = ( BoardView ) findViewById( R.id.board );
        mBoardView.setGame( mGame );
        mBoardView.setOnTouchListener( mTouchListener );

        mPrefs = PreferenceManager.getDefaultSharedPreferences( this );
        mSoundOn = mPrefs.getBoolean( "sound", true );
        String difficultyLevel = mPrefs.getString( "difficulty_level",
                getResources().getString( R.string.difficulty_easy ) );
        if( difficultyLevel.equals( getResources().getString( R.string.difficulty_easy ) ) )
            mGame.setDifficultyLevel( TicTacToeGame.DifficultyLevel.Easy );
        else if( difficultyLevel.equals( getResources().getString( R.string.difficulty_harder ) ) )
            mGame.setDifficultyLevel( TicTacToeGame.DifficultyLevel.Harder );
        else
            mGame.setDifficultyLevel( TicTacToeGame.DifficultyLevel.Expert );

        if( savedInstanceState == null ){
            startNewGame();
        }else {
            mGame.setBoardState( savedInstanceState.getCharArray( "board" ) );
            mGameOver = savedInstanceState.getBoolean( "mGameOver" );
            mInfoTextView.setText( savedInstanceState.getCharSequence( "info" ) );
            mHumanScore = savedInstanceState.getInt( "mHumanWins" );
            mAndroidScore = savedInstanceState.getInt( "mComputerWins" );
            mTieScore = savedInstanceState.getInt( "mTies" );
            mHumanTurn = savedInstanceState.getInt( "mGoFirst" );
        }
        displayScores();
    }

    @Override
    protected void onResume(){
        super.onResume();
        mHumanMediaPlayer = MediaPlayer.create( getApplicationContext(), R.raw.human_sound );
        mComputerMediaPlayer = MediaPlayer.create( getApplicationContext(), R.raw.computer_sound );
    }

    @Override
    protected void onPause(){
        mHumanMediaPlayer.stop();
        mHumanMediaPlayer.release();
        mComputerMediaPlayer.stop();
        mComputerMediaPlayer.release();
        super.onPause();
    }

    @Override
    protected void onSaveInstanceState( Bundle outState ){
        super.onSaveInstanceState( outState );

        outState.putCharArray( "board", mGame.getBoardState() );
        outState.putBoolean( "mGameOver", mGameOver );
        outState.putInt( "mGoFirst", mHumanTurn );
        outState.putInt( "mHumanWins", Integer.valueOf( mHumanScore ) );
        outState.putInt( "mComputerWins", Integer.valueOf( mAndroidScore ) );
        outState.putInt( "mTies", Integer.valueOf( mTieScore ) );
        outState.putCharSequence( "info", mInfoTextView.getText() );
    }

    @Override
    protected void onRestoreInstanceState( Bundle savedInstanceState ){
        super.onRestoreInstanceState( savedInstanceState );

        mGame.setBoardState( savedInstanceState.getCharArray( "board" ) );
        mInfoTextView.setText( savedInstanceState.getCharSequence( "info" ) );
        mHumanScore = savedInstanceState.getInt( "mHumanWins" );
        mAndroidScore = savedInstanceState.getInt( "mComputerWins" );
        mTieScore = savedInstanceState.getInt( "mTies" );
        mHumanTurn = savedInstanceState.getInt( "mGoFirst" );
    }


    @Override
    public boolean onCreateOptionsMenu( Menu menu ){
        super.onCreateOptionsMenu( menu );
        MenuInflater inflater = getMenuInflater();
        inflater.inflate( R.menu.options_menu, menu );
        return true;
    }

    @Override
    public boolean onOptionsItemSelected( MenuItem item ){
        switch( item.getItemId() ){
            case R.id.new_game:
                startNewGame();
                return true;
            case R.id.settings:
                startActivityForResult( new Intent( this, Settings.class ), 0 );
                return true;
            case R.id.quit:
                showDialog( DIALOG_QUIT_ID );
                return true;
        }
        return false;
    }

    @Override
    protected Dialog onCreateDialog(int id ){
        Dialog dialog = null;
        AlertDialog.Builder builder = new AlertDialog.Builder( this );

        switch( id ){
            case DIALOG_QUIT_ID:
                // Create the quit confirmation dialog
                builder.setMessage( R.string.quit_question )
                        .setCancelable( false )
                        .setPositiveButton( R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick( DialogInterface dialog, int id ){
                                MainActivity.this.finish();
                            }
                        })
                        .setNegativeButton( R.string.no, null );
                dialog = builder.create();
        }
        return dialog;
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data ){
        if( requestCode == RESULT_CANCELED ){
            mSoundOn = mPrefs.getBoolean( "sound", true );
            String difficultyLevel = mPrefs.getString( "difficulty_level", getResources().getString( R.string.difficulty_harder ) );
            if( difficultyLevel.equals( getResources().getString( R.string.difficulty_easy ) ) )
                mGame.setDifficultyLevel( TicTacToeGame.DifficultyLevel.Easy );
            else if( difficultyLevel.equals( getResources().getString( R.string.difficulty_harder ) ) )
                mGame.setDifficultyLevel( TicTacToeGame.DifficultyLevel.Harder );
            else
                mGame.setDifficultyLevel( TicTacToeGame.DifficultyLevel.Expert );
        }
    }

    private void startNewGame(){
        mHumanTurn = mRand.nextInt( 2 );
        mGame.clearBoard();
        mBoardView.invalidate();
        mGameOver = false;
        if( mHumanTurn == 0 ){
            mInfoTextView.setText( "It's Android's turn." );
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    int move = mGame.getComputerMove();
                    setMove( TicTacToeGame.COMPUTER_PLAYER, move );
                    mInfoTextView.setText( "It's Android's turn." );
                    mBoardView.invalidate();
                    mHumanTurn = 1;
                }
            }, DELAY);
        }else{
            mInfoTextView.setText( "It's your turn" );
        }
    }

    private void displayScores(){
        mHumanScoreTextView.setText( Integer.toString( mHumanScore ));
        mAndroidScoreTextView.setText( Integer.toString( mAndroidScore ) );
        mTieScoreTextView.setText( Integer.toString( mTieScore ) );
    }

    private View.OnTouchListener mTouchListener = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View view, MotionEvent motionEvent) {
            int col = ( int )motionEvent.getX() / mBoardView.getBoardCellWidth();
            int row = ( int )motionEvent.getY() / mBoardView.getBoardCellWidth();
            int pos = row * 3 + col;

            if( !mGameOver && mHumanTurn == 1 && setMove( TicTacToeGame.HUMAN_PLAYER, pos ) ){
                // If no winner yet, let the computer make a move
                int winner = mGame.checkForWinner();
                mInfoTextView.setText( "It's Android's turn." );
                if( winner == 0 ){
                    mInfoTextView.setText( "It's Android's turn." );
                    mHumanTurn = 0;
                    /*int move = mGame.getComputerMove();
                    setMove( TicTacToeGame.COMPUTER_PLAYER, move );
                    winner = mGame.checkForWinner();*/
                    if( mHumanTurn == 0 ) {
                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                int move = mGame.getComputerMove();
                                setMove(TicTacToeGame.COMPUTER_PLAYER, move);
                                mBoardView.invalidate();
                                mHumanTurn = 1;
                            }
                        }, DELAY);
                    }
                    winner = mGame.checkForWinner();
                }
                if( winner == 0 )
                    mInfoTextView.setText( "It's your turn" );
                else if( winner == 1 ) {
                    mInfoTextView.setText("It's a tie!");
                    mTieScoreTextView.setText( String.valueOf( mTieScore += 1 ) );
                    mGameOver = true;
                }
                else if( winner == 2 ) {
                    mInfoTextView.setText("You won!");
                    mHumanScoreTextView.setText( String.valueOf( mHumanScore += 1 ) );
                    mGameOver = true;
                }
                else {
                    mInfoTextView.setText("Android won!");
                    mAndroidScoreTextView.setText( String.valueOf( mAndroidScore += 1) );
                    mGameOver = true;
                }
            }
            return false;
        }
    };

    private boolean setMove(char player, int location) {
        if( mGame.setMove( player, location ) ){
            mBoardView.invalidate();
            if( mSoundOn ){
                if( player == TicTacToeGame.HUMAN_PLAYER ){
                    mHumanMediaPlayer.start();
                }else{
                    mComputerMediaPlayer.start();
                }
            }
            return true;
        }
        return false;
    }

}
