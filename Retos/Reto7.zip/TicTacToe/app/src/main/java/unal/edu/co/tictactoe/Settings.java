package unal.edu.co.tictactoe;

import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceActivity;

/**
 * Created by drdagerm on 10/16/17.
 */

public class Settings extends PreferenceActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate( savedInstanceState );
        addPreferencesFromResource( R.xml.preferences );
    }
}