package unal.edu.co.tictactoe;

import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DialogTitle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private TicTacToeGame mGame;
    private TextView mInfoTextView;
    private BoardView mBoardView;

    private boolean mGameOver;
    private int selected;
    static final int DIALOG_DIFFICULTY_ID = 0;
    static final int DIALOG_QUIT_ID = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mInfoTextView = ( TextView ) findViewById( R.id.information );
        mGame = new TicTacToeGame();
        mBoardView = ( BoardView ) findViewById( R.id.board );
        mBoardView.setGame( mGame );
        mBoardView.setOnTouchListener( mTouchListener );
        mGameOver = false;
        startNewGame();
    }

    @Override
    protected Dialog onCreateDialog(int id ){
        Dialog dialog = null;
        AlertDialog.Builder builder = new AlertDialog.Builder( this );

        switch( id ){
            case DIALOG_DIFFICULTY_ID:
                builder.setTitle( R.string.difficulty_choose );

                final CharSequence[] levels = {
                        getResources().getString( R.string.difficulty_easy ),
                        getResources().getString( R.string.difficulty_harder ),
                        getResources().getString( R.string.difficulty_expert )
                };

                //TODO: Set selected, an integer (0 to n-1), for the difficulty dialog.
                //selected is the radio button that should be selected
                selected = mGame.getDifficultyLevel().ordinal();
                builder.setSingleChoiceItems( levels, selected,
                        new DialogInterface.OnClickListener(){
                            public void onClick( DialogInterface dialog, int item ){
                                dialog.dismiss();

                                //TODO: Set the diff level of mGame based in wich item was selected.
                                if( selected == 0 )
                                    mGame.setDifficultylevel(TicTacToeGame.DifficultyLevel.Easy );
                                else if( selected == 1 )
                                    mGame.setDifficultylevel(TicTacToeGame.DifficultyLevel.Harder );
                                else if ( selected == 2 )
                                    mGame.setDifficultylevel(TicTacToeGame.DifficultyLevel.Expert );

                                //Display the selected difficulty level
                                Toast.makeText( getApplicationContext(), levels[item],
                                        Toast.LENGTH_SHORT).show();
                            }
                        });
                dialog = builder.create();
                break;

            case DIALOG_QUIT_ID:
                // Create the quit confirmation dialog
                builder.setMessage( R.string.quit_question )
                        .setCancelable( false )
                        .setPositiveButton( R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick( DialogInterface dialog, int id ){
                                MainActivity.this.finish();
                            }
                        })
                        .setNegativeButton( R.string.no, null );
                dialog = builder.create();
        }
        return dialog;
    }

    @Override
    public boolean onCreateOptionsMenu( Menu menu ){
        super.onCreateOptionsMenu( menu );
        MenuInflater inflater = getMenuInflater();
        inflater.inflate( R.menu.options_menu, menu );
        return true;
    }

    @Override
    public boolean onOptionsItemSelected( MenuItem item ){
        switch( item.getItemId() ){
            case R.id.new_game:
                startNewGame();
                return true;
            case R.id.ai_difficulty:
                showDialog( DIALOG_DIFFICULTY_ID );
                return true;
            case R.id.quit:
                showDialog( DIALOG_QUIT_ID );
                return true;
        }
        return false;
    }
    private void startNewGame(){
        mGame.clearBoard();
        mBoardView.invalidate();
        mInfoTextView.setText( "You Go First." );
        mGameOver = false;
    }

    // Listen for touches on the board
    private View.OnTouchListener mTouchListener = new View.OnTouchListener() {

        @Override

        public boolean onTouch(View v, MotionEvent event) {
            int col = (int) event.getX() / mBoardView.getBoardCellWidth();
            int row = (int) event.getY() / mBoardView.getBoardCellHeight();
            int pos = row * 3 + col;

            Log.d( "POS", String.valueOf( pos ));

            if (!mGameOver && setMove(TicTacToeGame.HUMAN_PLAYER, pos))	{
                // If no winner yet, let the computer make a move
                int winner = mGame.checkForWinner();
                if( winner == 0 ){
                    mInfoTextView.setText( "It's Android's turn." );
                    int move = mGame.getComputerMove();
                    setMove( TicTacToeGame.COMPUTER_PLAYER, move );
                    winner = mGame.checkForWinner();
                }
                if( winner == 0 )
                    mInfoTextView.setText( "It's your turn" );
                else if( winner == 1 ) {
                    mInfoTextView.setText("It's a tie!");
                    mGameOver = true;
                }
                else if( winner == 2 ) {
                    mInfoTextView.setText("You won!");
                    mGameOver = true;
                }
                else {
                    mInfoTextView.setText("Android won!");
                    mGameOver = true;
                }
            }

            return false;
        }
    };

    private boolean setMove(char player, int location) {
        if( mGame.setMove( player, location ) ){
         mBoardView.invalidate();
            return true;
        }
        return false;
    }

}
